import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Channel } from '../models/channel';


@Injectable({
    providedIn: 'root'
})
export class ChannelService {

    constructor(private http: HttpClient) { }

    getAll(): Observable<Channel[]> {
        return this.http.get<Channel[]>('http://localhost:8080/resource/channel');

    }

    getChannel(displayId: string): Observable<Channel> {
        return this.http.get<Channel>(`http://localhost:8080/resource/channel/${displayId}`);
    }

    getChannelByUserId(id: number): Observable<{displayId: string}> {
        return this.http.get<{displayId: string}>(`http://localhost:8080/resource/channel/user/${id}`);
    }

    getCategories(): Observable<string[]> {
        return this.http.get<string[]>('http://localhost:8080/resource/channel/category');
    }

    saveChannel(channel: Channel): Observable<Channel> {
        return this.http.put<Channel>('http://localhost:8080/resource/channel', channel);
    }
}
