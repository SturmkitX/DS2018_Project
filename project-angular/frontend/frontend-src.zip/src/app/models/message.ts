export class Message {
    id: number;
    subject: string;
    content: string;
    sender: string;
    senderName: string;
    receivers: string;
}
