export class Channel {
    id: number;
    ownerId: number;
    ownerName: string;
    name: string;
    description: string;
    displayId: string;
    category: string;
    active: boolean;
}
