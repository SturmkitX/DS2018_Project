export class User {
    id: number;
    name: string;
    email: string;
    password: string;
    role: string;
    gender: string;
    active: boolean;
    enableEmails: boolean;
}
