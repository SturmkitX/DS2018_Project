import { Channel } from './../../models/channel';
import { ChannelService } from './../../services/channel.service';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-channels',
    templateUrl: './channels.component.html',
    styleUrls: ['./channels.component.css']
})
export class ChannelsComponent implements OnInit {

    public channels: Channel[];

    constructor(private channelService: ChannelService) { }

    ngOnInit() {
        this.channelService.getAll().subscribe(data => this.channels = data);
    }

}
