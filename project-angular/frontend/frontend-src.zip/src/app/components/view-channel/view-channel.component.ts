import { Channel } from './../../models/channel';
import { ChannelService } from './../../services/channel.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-view-channel',
    templateUrl: './view-channel.component.html',
    styleUrls: ['./view-channel.component.css']
})
export class ViewChannelComponent implements OnInit {

    public channel: Channel;

    constructor(private route: ActivatedRoute, private channelService: ChannelService) { }

    ngOnInit() {
        console.log('View channel OnInit');
        const displayId = this.route.snapshot.paramMap.get('id');
        this.channelService.getChannel(displayId).subscribe(channel => {
            this.channel = channel;
        });
    }

}
