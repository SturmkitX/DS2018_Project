import { Component, OnInit } from '@angular/core';
import {Channel} from "../../models/channel";
import {ChannelService} from "../../services/channel.service";

@Component({
  selector: 'app-user-channel',
  templateUrl: './user-channel.component.html',
  styleUrls: ['./user-channel.component.css']
})
export class UserChannelComponent implements OnInit {

    public channel: Channel;
    public categories: string[];

    constructor(private channelService: ChannelService) { }

    ngOnInit() {
        const user = JSON.parse(localStorage.getItem('currentUser'));
        console.log(user.id);
        console.log('I got here');
        this.channelService.getChannelByUserId(user.id).subscribe(channel => {
            console.log(channel.displayId.length);
            this.channelService.getChannel(channel.displayId).subscribe(chan => {
                this.channel = chan;
            }, error => {
                console.log(error);
            });
        });

        this.channelService.getCategories().subscribe(categories => {
            this.categories = categories;
        });
        // console.log(this.channelService.getChannelByUserId(user.id));
    }

    logChange() {
        console.log(this.channel.category);
    }

    saveChanges() {
        this.channelService.saveChannel(this.channel).subscribe(channel => {
            console.log(channel);
        });
    }

}
