import { Component, OnInit } from '@angular/core';
import {User} from "../../models/user";
import {UserService} from "../../services/user.service";

@Component({
    selector: 'app-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

    public user: User;
    public password1: string;
    public password2: string;

    constructor(private userService: UserService) {}

    ngOnInit(): void {
        const userId = JSON.parse(localStorage.getItem('currentUser')).id;
        this.userService.findUser(userId).subscribe(user => {
            this.user = user;
        });
    }

    saveUser() {
        if (this.password1 != this.password2) {
            alert("The passwords do not match!");
            return;
        }

        if (this.password1.length < 8) {
            alert("The password must be at least 8 characters long!");
            return;
        }

        this.userService.updateUser(this.user).subscribe(user => {
            this.user = user;
        }, error => {
            console.log(error);
        });
    }


}
